#!/usr/bin/env python

import os
from optparse import OptionParser
from core.target import Target
from core.engine import Engine
from core.packages.clint.textui import colored 
from core.cli import success, warning, error

def begin():
    print """
 _____     __   .-'''-.    .-'''-.     _______   .-------.          ,---.     .-'''-. .---.  .---.   .-'''-.   .-------.    
 \   _\   /  / / _     \  / _     \   /   __  \  |  _ _   \        /,--.|    / _     \|   |  |_ _|  /   _   \  |  _ _   \   
 .-./ ). /  ' (`' )/`--' (`' )/`--'  | ,_/  \__) | ( ' )  |       //_  ||   (`' )/`--'|   |  ( ' ) |__/` '.  | | ( ' )  |   
 \ '_ .') .' (_ o _).   (_ o _).   ,-./  )       |(_ o _) /      /_( )_||  (_ o _).   |   '-(_{;}_)   .--'  /  |(_ o _) /   
(_ (_) _) '   (_,_). '.  (_,_). '. \  '_ '`)     | (_,_).' __   /(_ o _)|   (_,_). '. |      (_,_) ___'--._ _\ | (_,_).' __ 
  /    \   \ .---.  \  :.---.  \  : > (_)  )  __ |  |\ \  |  | / /(_,_)||_ .---.  \  :| _ _--.   ||   |  ( ` ) |  |\ \  |  |
  `-'`-'    \\    `-'  |\    `-'  |(  .  .-'_/  )|  | \ `'   //  `-----' ||\    `-'  ||( ' ) |   ||   `-(_{;}_)|  | \ `'   /
 /  /   \    \\       /  \       /  `-'`-'     / |  |  \    / `-------|||-' \       / (_{;}_)|   | \     (_,_) |  |  \    / 
'--'     '----'`-...-'    `-...-'     `._____.'  ''-'   `'-'          '-'    `-...-'  '(_,_) '---'  `-..__.-'  ''-'   `'-'  


    """

def main():
    begin()
    usage = "usage: %prog [options]"

    parser = OptionParser(usage=usage)
    parser.add_option("-u", "--url", dest="url", help="your target URL")
    parser.add_option("--post", dest="post", default=False, action="store_true",
                      help="post request to target url")
    parser.add_option("--data", dest="post_data", help="post data to use")
    parser.add_option("--threads", dest="threads", default=1, 
                      help="number of threads")
    parser.add_option("--http-proxy", dest="http_proxy", 
                      help="scan behind given proxy (format: 127.0.0.1:80)")
    parser.add_option("--tor", dest="tor", default=False, action="store_true", 
                      help="scan behind default Tor")
    parser.add_option("--crawl", dest="crawl", default=False, action="store_true", 
                      help="crawl target url for other links to test")
    parser.add_option("--forms", dest="forms", default=False, action="store_true", 
                      help="crawl target url looking for forms to test")
    parser.add_option("--user-agent", dest="user_agent", 
                      help="put user agent")
    parser.add_option("--random-agent", dest="random_agent", default=False, 
                      action="store_true", 
                      help="do scan with random user agents")
    parser.add_option("--cookie", dest="cookie", 
                      help="use cookie to do scans")
    parser.add_option("--dom", dest="dom", default=False, action="store_true", 
                      help="basic option to detect dom xss")

    (options, args) = parser.parse_args()
    if options.url is None: 
        parser.print_help() 
        exit()

    # first target
    print "[+] YOUR_TARGET: %s" % options.url

    if options.post is True:
        print " |- METHOD: POST"
        if options.post_data is not None:
            print " |- POST data: %s" % options.post_data
            t = Target(options.url, method = 'POST', data = options.post_data)
        else:
            error('No POST data specified: use --data', ' |- ')
            exit()
    else:
        print " |- METHOD: GET"
        t = Target(options.url)

    #scanner
    s = Engine(t)

    #proxy setting
    if options.http_proxy is not None and options.tor is True:
        error('No --tor and --http-proxy together!', ' |- ')
        exit()
    elif options.tor is False and options.http_proxy is not None:
        s.addOption("http-proxy", options.http_proxy)
        print " |- PROXY: %s" % options.http_proxy
    elif options.tor is True:
        s.addOption("http-proxy", "127.0.0.1:8118")
        print " |- PROXY: 127.0.0.1:8118"

    # User Agent option provided?
    if options.user_agent is not None and options.random_agent is True:
        error('No --user-agent and --random-agent together!', ' |- ')
    elif options.random_agent is False and options.user_agent is not None:
        s.addOption("ua", options.user_agent)
        print " |- USER-AGENT: %s" % options.user_agent
    elif options.random_agent is True:
        s.addOption("ua", "RANDOM")
        print " |- USER-AGENT: RANDOM"

    # Cookies Settings 
    if options.cookie is not None:
        s.addOption("cookie", options.cookie)
        print " |- COOKIE: %s" % options.cookie

    # some crawl options for you baby hhhhhhhhhhhhhhh
    if options.crawl is True:
        s.addOption("crawl", True)

    # crawl forms
    if options.forms is True:
        s.addOption("forms", True)

    # Dom Based scan
    if options.dom is True:
        s.addOption("dom", True)

    #threads
    s.addOption("threads", int(options.threads))

    #Let's start
    if s.start():
        exit()

if __name__ == '__main__':
    main()
